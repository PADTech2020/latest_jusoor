<?php

return [
    'create'             => 'Create new category',
    'edit'               => 'Edit category',
    'menu'               => 'Categories',
    'edit_this_category' => 'Edit this category',
    'menu_name'          => 'Categories',
    'none'               => 'None',
    'total_posts'        => 'Total posts: :total',
];
