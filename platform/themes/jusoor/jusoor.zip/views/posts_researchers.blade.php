<?php
    $posts = Botble\Blog\Models\Post::join("language_meta", function ($join) {
        $join->on("language_meta.reference_id", "=", "id")
            ->where(["language_meta.reference_type"=> 'Botble\Blog\Models\Post','language_meta.lang_meta_code'=>'ar']);
    })->where(['status' => Botble\Base\Enums\BaseStatusEnum::PUBLISHED(), 'researcher_id' => $researcher->id])->orderBy('created_at','desc')->paginate(12);

    $researcher = \Botble\Researchers\Models\Researchers::find($researcher->id);
?>


<section class="block-wrapper new-dark-style researcher-header">
    <div class="container">
        <!-- block content -->
        <div class="block-content  block-author">
            <div class="author-img">
               <img width="150" src="{{RvMedia::getImageUrl($researcher->image,'thumb') }}"/>
            </div>
            <div class="author-content">
                <h2><span class="author-name">{{ $researcher->name }}</span></h2>

                <p><span class="position">{{ $researcher->position }}</span></p>
                {{--<p>{{ $researcher->summary }}</p>--}}
            </div>

        </div>
    </div>
    </div>
</section>


<section class="block-wrapper non-sidebar sky-news">
    <div class="container">
        <!-- block content -->
        <div class="block-content non-sidebar">
            <!-- grid-box -->
            <div class="grid-box">
                <div class="row">
                    <div class="col-md-9">
                        @if(count($posts))
                            <div class="row">
                                @foreach($posts as $post)
                                    <a href="{{ $post->url }}">
                                        <div class="col-md-4">
                                            <div class="news-post standard-post">
                                                <div class="post-gallery">
                                                    <img style="height: 225px;" src="{{ GetMediaImg($post->image, 'list_main') }}"
                                                         alt="{{ $post->name }}">
                                                </div>
                                                <div class="post-content">
                                                    <h2>{{ $post->name }}</h2>
                                                    <ul class="post-tags">
                                                        <li>
                                                            <i class="fa fa-clock-o"></i>{{ date('Y/m/d', strtotime($post->published_at)) }}
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                @endforeach
                            </div> <div class="pagination-box">
                                {!! $posts->links() !!}
                            </div>
                        @else
                            <div class="alert alert-warning">
                                <p>{{ __('There is no data to display!') }}</p>
                            </div>
                        @endif
                    </div>
                    <div class="col-md-3">
                        <!-- sidebar -->
                        <div class="sidebar">
                            <div class="widget tags-widget">
                                <div>
                                    <div class="title-section">
                                        <h1>
                                            <span>زوارنا يتصفحون الآن</span>
                                        </h1>
                                    </div>
                                    <ul class="list-posts">
                                        @foreach(get_featured_posts(2) as $post)
                                            <li>
                                                <a href="{{$post->url}}"><img
                                                            src="{{ RvMedia::getImageUrl($post->image, 'thumb') }}"
                                                            alt="{{$post->name}}"></a>
                                                <div class="post-content">
                                                    <h2><a href="{{$post->url}}">{{$post->name}} </a></h2>
                                                    <ul class="post-tags">
                                                        <li>
                                                            <i class="fa fa-clock-o"></i>{{ date('Y/m/d', strtotime($post->published_at)) }}
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                            <div class="widget tags-widget">
                                <div>
                                    <div class="title-section">
                                        <h1>
                                            <span>الأكثر قراءة</span>
                                        </h1>
                                    </div>
                                    <ul class="list-posts">
                                        @foreach(get_popular_posts(3) as $post)
                                            <li>
                                                <a href="{{$post->url}}"><img
                                                            src="{{ RvMedia::getImageUrl($post->image, 'thumb') }}"
                                                            alt="{{$post->name}}"></a>
                                                <div class="post-content">
                                                    <h2><a href="{{$post->url}}">{{$post->name}} </a></h2>
                                                    <ul class="post-tags">
                                                        <li>
                                                            <i class="fa fa-clock-o"></i>{{ date('Y/m/d', strtotime($post->published_at)) }}
                                                        </li>
                                                    </ul>
                                                </div>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!-- End sidebar -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End grid-box -->
    </div>
    <!-- End block content -->
    </div>
</section>

<!-- block-wrapper-section
