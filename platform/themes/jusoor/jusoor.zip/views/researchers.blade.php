<?php


?>

<section class="block-wrapper new-dark-style researcher-header">
    <div class="container">
        <!-- block content -->
        <div class="block-content  block-author">
            <div class="">
                <img width="150" src="/storage/general/logo-light-jusoor.png"/>
            </div>
            <div class="author-content-header">
                <br>
                <p><span class="position">{{ __('مركز جسور للدراسات مؤسسة مستقلة متخصصة في إدارة المعلومات ') }}</span></p>
                <p><span class="position">{{ __(' وإعداد الدراسات، والأبحاث المتعلقة بالشأن السياسي, والاجتماعي, السوري  ') }}</span></p>

            </div>

        </div>
    </div>
    </div>
</section>
<section class="researchers-list">
    <div class="container">
        <!-- block content -->

        <div class="row">

        @foreach($researchers as $researcher)
            @if($researcher->id!=8 && $researcher->id!=16)
            <div class=" col-md-6">
                <div class="block-content block-author" >
                <a href="/articles/{{ $researcher->id }}">
                    <div class="author-img">
                        <img width="150" src="{{RvMedia::getImageUrl($researcher->image, 'thumb') }}"/>
                    </div>
                </a>
                <div class="author-content">
                    <a href="/articles/{{ $researcher->id }}">
                        <h2><span class="author-name">{{ $researcher->name }}</span></h2>
                    </a>
                    <h4><span class="position">{{ $researcher->position }}</span></h4>
                    <br>
                    <p><span class="position">{!! Str::words($researcher->summary, '20')  !!} </span></p>
                </div>
                </div>
            </div>
                @endif
        @endforeach
        </div>

    </div>
</section>



<!-- block-wrapper-section
