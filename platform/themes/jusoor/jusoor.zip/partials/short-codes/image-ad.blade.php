<?php
/**
 * Created by PhpStorm.
 * User: Abdulhamid
 * Date: 6/26/2021
 * Time: 11:01 AM
 */

        ?>
<div class="">

    <div class="" >
        <a href="{{ theme_option('telegram') }}"><img style="width: 100%;"  src="{{ RvMedia::getImageUrl(theme_option('banner-ads', Theme::asset()->url('images/logo.png'))) }}"></a>
        </div>
</div>
