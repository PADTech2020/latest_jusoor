<div class="form-group">
    <div class="row">
        <label class="control-label col-lg-2 col-md-3">Post ShortLink</label>
        <div class="col-lg-10 col-md-9">
            <input name="shortLink" data-shortcode-attribute="shortLink" class="form-control" placeholder="">
        </div>
    </div>
</div>