<div class="form-group">
    <div class="row">
        <label class="control-label col-lg-2 col-md-3">Address</label>
        <div class="col-lg-10 col-md-9">
            <input name="address" data-shortcode-attribute="content" class="form-control" placeholder="24 Roberts Street, SA73, Chester">
        </div>
    </div>
</div>