@if (is_plugin_active('blog'))
<?php
    $slider = Botble\Blog\Models\Post::getSlider(5);

?>


@endif

<!-- heading-news-section2
================================================== -->
<section class="heading-news2 jusoor-slider">




                <div id="hero-slider" class="hero-slider owl-carousel owl-theme">
                    @foreach($slider as $slide)
                            <div class="item image-post">
                                <div class="hero-slider-img">
                                    <img src="{{ RvMedia::getImageUrl($slide->slider_image ) }}" alt="">
                                </div>

                                <div class="news-slider-content">
                                    <div class="inner-hover">
                                        <a class="category-post" href="{{ $slide->categories->last()->url }}">{{ $slide->categories->last()->name }}</a>
                                        <img width="60" src="https://staging.jusoor.co/storage/general/logo-preview-4.png" alt="Nedaa Post logo">
                                        <h2><a href="{{ $slide->url }}">{{ $slide->name }}</a></h2>
                                        <p>{{ $slide->description }}</p>
                                        <!--<ul class="post-tags">-->
                                        <!--    <li><i class="fa fa-clock-o"></i>{{ date('Y/m/d', strtotime($slide->created_at)) }}</li>-->
                                        <!--</ul>-->
                                    </div>
                                </div>
                            </div>

                    @endforeach
                </div>


</section>
<!-- End heading-news-section -->