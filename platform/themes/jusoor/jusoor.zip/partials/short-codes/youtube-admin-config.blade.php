<div class="form-group">
    <div class="row">
        <label class="control-label col-lg-3 col-md-3">Youtube URL</label>
        <div class="col-lg-9 col-md-9">
            <input name="url" data-shortcode-attribute="content" class="form-control" placeholder="https://www.youtube.com/watch?v=FN7ALfpGxiI">
        </div>
    </div>
</div>